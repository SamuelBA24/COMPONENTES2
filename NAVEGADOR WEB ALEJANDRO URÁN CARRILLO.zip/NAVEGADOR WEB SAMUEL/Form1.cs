﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NAVEGADOR_WEB_SAMUEL
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            Navegador.Navigate(UrlNavegador.Text);
        }

        private void BtnAtras_Click(object sender, EventArgs e)
        {
            Navegador.GoBack();

        }

        private void BtnAdelante_Click(object sender, EventArgs e)
        {
            Navegador.GoForward();
        }

        private void BtnActualizar_Click(object sender, EventArgs e)
        {
            Navegador.Refresh();
        }

        private void BtnPagprincipal_Click(object sender, EventArgs e)
        {
            Navegador.GoHome();
        }
    }
}
