﻿namespace REPRODUCTOR_SAMUEL
{
    partial class Reproductor
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Reproductor));
            this.BtnCargar = new System.Windows.Forms.Button();
            this.BtnReproducir = new System.Windows.Forms.Button();
            this.BtnPausa = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.LblRuta = new System.Windows.Forms.Label();
            this.axWindowsMediaPlayer1 = new AxWMPLib.AxWindowsMediaPlayer();
            this.BtnParar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.axWindowsMediaPlayer1)).BeginInit();
            this.SuspendLayout();
            // 
            // BtnCargar
            // 
            this.BtnCargar.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BtnCargar.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnCargar.ForeColor = System.Drawing.Color.LawnGreen;
            this.BtnCargar.Location = new System.Drawing.Point(34, 409);
            this.BtnCargar.Name = "BtnCargar";
            this.BtnCargar.Size = new System.Drawing.Size(97, 40);
            this.BtnCargar.TabIndex = 1;
            this.BtnCargar.Text = "Cargar";
            this.BtnCargar.UseVisualStyleBackColor = false;
            this.BtnCargar.Click += new System.EventHandler(this.BtnCargar_Click);
            // 
            // BtnReproducir
            // 
            this.BtnReproducir.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BtnReproducir.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnReproducir.ForeColor = System.Drawing.Color.LawnGreen;
            this.BtnReproducir.Location = new System.Drawing.Point(155, 409);
            this.BtnReproducir.Name = "BtnReproducir";
            this.BtnReproducir.Size = new System.Drawing.Size(97, 40);
            this.BtnReproducir.TabIndex = 2;
            this.BtnReproducir.Text = "Reproducir";
            this.BtnReproducir.UseVisualStyleBackColor = false;
            this.BtnReproducir.Click += new System.EventHandler(this.BtnReproducir_Click);
            // 
            // BtnPausa
            // 
            this.BtnPausa.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BtnPausa.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnPausa.ForeColor = System.Drawing.Color.LawnGreen;
            this.BtnPausa.Location = new System.Drawing.Point(414, 409);
            this.BtnPausa.Name = "BtnPausa";
            this.BtnPausa.Size = new System.Drawing.Size(97, 40);
            this.BtnPausa.TabIndex = 4;
            this.BtnPausa.Text = "Pausa";
            this.BtnPausa.UseVisualStyleBackColor = false;
            this.BtnPausa.Click += new System.EventHandler(this.BtnPausa_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.Filter = "Todos|*.*";
            // 
            // LblRuta
            // 
            this.LblRuta.AutoSize = true;
            this.LblRuta.Location = new System.Drawing.Point(42, 467);
            this.LblRuta.Name = "LblRuta";
            this.LblRuta.Size = new System.Drawing.Size(35, 13);
            this.LblRuta.TabIndex = 5;
            this.LblRuta.Text = "label1";
            // 
            // axWindowsMediaPlayer1
            // 
            this.axWindowsMediaPlayer1.Enabled = true;
            this.axWindowsMediaPlayer1.Location = new System.Drawing.Point(23, 12);
            this.axWindowsMediaPlayer1.Name = "axWindowsMediaPlayer1";
            this.axWindowsMediaPlayer1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axWindowsMediaPlayer1.OcxState")));
            this.axWindowsMediaPlayer1.Size = new System.Drawing.Size(715, 377);
            this.axWindowsMediaPlayer1.TabIndex = 0;
            // 
            // BtnParar
            // 
            this.BtnParar.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BtnParar.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnParar.ForeColor = System.Drawing.Color.LawnGreen;
            this.BtnParar.Location = new System.Drawing.Point(270, 409);
            this.BtnParar.Name = "BtnParar";
            this.BtnParar.Size = new System.Drawing.Size(97, 40);
            this.BtnParar.TabIndex = 6;
            this.BtnParar.Text = "Parar";
            this.BtnParar.UseVisualStyleBackColor = false;
            this.BtnParar.Click += new System.EventHandler(this.BtnParar_Click);
            // 
            // Reproductor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(800, 511);
            this.Controls.Add(this.BtnParar);
            this.Controls.Add(this.LblRuta);
            this.Controls.Add(this.BtnPausa);
            this.Controls.Add(this.BtnReproducir);
            this.Controls.Add(this.BtnCargar);
            this.Controls.Add(this.axWindowsMediaPlayer1);
            this.Name = "Reproductor";
            this.Text = "REPRODUCTOR DE MUSICA CHIMBITA";
            this.Load += new System.EventHandler(this.Reproductor_Load);
            ((System.ComponentModel.ISupportInitialize)(this.axWindowsMediaPlayer1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private AxWMPLib.AxWindowsMediaPlayer axWindowsMediaPlayer1;
        private System.Windows.Forms.Button BtnCargar;
        private System.Windows.Forms.Button BtnReproducir;
        private System.Windows.Forms.Button BtnPausa;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Label LblRuta;
        private System.Windows.Forms.Button BtnParar;
    }
}

